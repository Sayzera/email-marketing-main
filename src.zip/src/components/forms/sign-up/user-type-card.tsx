'use client'
import { Card, CardContent, CardDescription } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { cn } from '@/lib/utils'
import { User } from 'lucide-react'
import React from 'react'
import { FieldValues, UseFormRegister } from 'react-hook-form'

type Props = {
    value: string
    title: string
    text: string
    register: UseFormRegister<FieldValues>
    userType: 'owner' | 'student'
    setUserType: React.Dispatch<React.SetStateAction<'owner' | 'student'>>
}

function UserTypeCard({
    value,
    title,
    text,
    register,
    userType,
    setUserType
}: Props) {
    return (
        <Card
            onClick={() => setUserType(value as 'owner' | 'student')}
            className={cn('w-full cursor-pointer', userType == value && 'border-orange')}>
            <Label htmlFor={value}></Label>


            <CardContent className='flex justify-between p-2'>
                <div className='flex items-center gap-3'>
                    <Card className={cn('flex justify-center p-3', userType === value && 'border-orange')}>
                        <User
                            size={30}
                            className={cn(
                                userType == value ? 'text-orange' : 'text-gray-500'
                            )}
                        />
                    </Card>
                    <div className=''>
                        <CardDescription
                            className={'text-iridium'}
                        >{title}</CardDescription>
                        <CardDescription
                            className={'text-iridium'}
                        >{text}</CardDescription>
                    </div>
                </div>

                <div>
                    <div className={cn('w-4 h-4 rounded-full', userType === value ? 'bg-orange' : 'bg-platinum')}>
                        <Input
                            {
                            ...register('type', {
                                onChange: (event) => setUserType(event.target.value)
                            })
                            }
                            value={value}
                            id={value}
                            className='hidden'
                            type='radio'

                        />
                    </div>
                </div>
            </CardContent>
        </Card>

    )
}

export default UserTypeCard