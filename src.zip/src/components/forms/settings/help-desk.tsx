'use client'

import React from 'react'

type Props = {
    id: string
}

export default function HelpDesk({
    id
}: Props) {
  return (
    <div>HelpDesk</div>
  )
}